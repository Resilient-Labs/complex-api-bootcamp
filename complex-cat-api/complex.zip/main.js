
document.querySelector('button').addEventListener('click', getAPI )

function getAPI(){
  let catz = document.getElementById('cats')
  let url = `https://api.thecatapi.com/v1/categories`
  let url2 = `http://openlibrary.org/api/volumes/brief/isbn/9780525440987.json`
  console.log(url)


  fetch(url)
    .then(res => res.json()) // parse response as JSON
    .then(data => {
      // document.querySelector('img').src =

      document.getElementById('para').innerHTML = data
      document.getElementById('catz').src = data.imgaes.original.url
      // console.log(data)
      console.log('hello')
    })
    // .catch(err => {
    //   console.log(`error ${err}`)
    //
    // });

     fetch(url2)
    .then(res => res.json()) // parse response as JSON
    .then(data => {
      // document.querySelector('img').src =


        console.log(data)
    })
    .catch(err => {
      console.log(`error ${err}`)
    });
  }
